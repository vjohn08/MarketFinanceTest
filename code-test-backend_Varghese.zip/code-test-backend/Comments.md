## Areas of concern in ProductApplicationService
1. No test coverage. The existing tests were testing the mocks.
2. If more products are added in future. The dependencies will blow up. Causing the class to be modified every time. Violating the open/close principle.
3. The product application service is mixing two different concerns. Selecting the submit service and submitting the application. This can make it harder to test functionality in isolation.
4. The process of getting application id from IApplicationResult is duplicated.
5. Converting company data to company data request is duplicated.
6. The errors returned by the dependent microservices are ignored. They need to be atleast logged somewhere.
7. Some classes have setters and others dont have. Its better to have only private setters to minimise bugs.
8. The product classes are mostly using parameterless constructors. Its not a bad thing. But using proper constructors can minimise invalid object states.
9. There is no error handling at the moment. Depending on where and how the services are consumed there can be global error handler so maybe not the prime concern in the beginning.

## Assumptions
An applicationId = -1 means service failure.

## Future works
Add more robust error handling based on feedback from the business.
The client of the external dependencies must be registered in the DI container.
Inorder to implement a new product we can now focus solely on implementing the adapter for the corresponding service. And then the product application service can easily be extended by registering the product in the DI container