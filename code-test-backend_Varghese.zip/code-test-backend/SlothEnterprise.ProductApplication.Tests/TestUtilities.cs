﻿using FluentAssertions;
using SlothEnterprise.External;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;

namespace SlothEnterprise.ProductApplication.Tests
{
    public static class TestUtilities
    {
        public static SellerApplication BuildInvalidApplication()
        {
            var invalidProduct = new InvalidProduct();
            var companyData = BuildCompanyData();
            var application = new SellerApplication(invalidProduct, companyData);
            return application;
        }

        public static SellerCompanyData BuildCompanyData()
        {
            return new SellerCompanyData("Test Name", 123, "Test Director", new DateTime(2010, 10, 10));
        }

        public static SellerCompanyData BuildCompanyData(string companyNumber)
        {
            return new SellerCompanyData("Test Name", int.Parse(companyNumber), "Test Director", new DateTime(2010, 10, 10));
        }

        public class InvalidProduct : IProduct
        {
            public int Id => throw new NotImplementedException();
        }

        public static CompanyDataRequest BuildExpected(SellerCompanyData companyData)
        {
            return new CompanyDataRequest
            {
                CompanyFounded = companyData.Founded,
                CompanyName = companyData.Name,
                CompanyNumber = companyData.Number,
                DirectorName = companyData.DirectorName
            };
        }

        public static bool IsExpected<T>(T expected, T actual)
        {
            expected.Should().BeEquivalentTo(actual);

            return true;
        }

        public class TestApplicationResult : IApplicationResult
        {
            public int? ApplicationId { get; set; }
            public bool Success { get; set; }
            public IList<string> Errors { get; set; }

            public TestApplicationResult(int? applicationId, bool success, IList<string> errors)
            {
                ApplicationId = applicationId;
                Success = success;
                Errors = errors;
            }
        }

        public static BusinessLoans BuildBusinessLoan()
        {
            return new BusinessLoans(
                    id: 1,
                    interestRatePerAnnum: 10M,
                    loanAmount: 20M
                );
        }

        public static ConfidentialInvoiceDiscount BuildConfidentialInvoiceDiscount()
        {
            return new ConfidentialInvoiceDiscount(
                    id: 1,
                    totalLedgerNetworth: 10M,
                    advancePercentage: 0.10M
                );
        }

        public static SelectiveInvoiceDiscount BuildSelectiveInvoiceDiscount()
        {
            return new SelectiveInvoiceDiscount(
                    id: 1,
                    invoiceAmount: 100M,
                    advancePercentage: 0.30M
                );
        }

        public static SellerApplication BuildBusinessLoanApplication()
        {
            var businessLoan = BuildBusinessLoan();
            var companyData = BuildCompanyData();
            var application = new SellerApplication(businessLoan, companyData);
            return application;
        }
    }
}
