﻿using FluentAssertions;
using NSubstitute;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;
using Xunit;
using static SlothEnterprise.ProductApplication.Tests.TestUtilities;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ConfidentialInvoiceApplicationServiceTests
    {
        private readonly ISubmitApplicationService _sut;
        private readonly IConfidentialInvoiceService _service;

        public ConfidentialInvoiceApplicationServiceTests()
        {
            _service = Substitute.For<IConfidentialInvoiceService>();

            _sut = new ConfidentialInvoiceApplicationService(_service);
        }

        [Fact]
        public void When_ConfidentialInvoice_And_Submit_Success()
        {
            var application = BuildConfidentialInvoiceDiscountApplication();

            var mockedResult = SetupConfidentialInvoiceServiceSuccess();

            var result = _sut.Submit(application);

            ValidateConfidentialInvoiceDiscountSuccess(application, mockedResult, result);
        }

        [Fact]
        public void When_ConfidentialInvoice_And_Submit_Fail()
        {
            var application = BuildConfidentialInvoiceDiscountApplication();

            var mockedResult = SetupConfidentialInvoiceServiceFail();

            var result = _sut.Submit(application);

            ValidateConfidentialInvoiceDiscountFail(application, mockedResult, result);
        }

        [Fact]
        public void When_Invalid_Product()
        {
            var application = BuildInvalidApplication();

            Action a = () => _sut.Submit(application);

            var invalidType = application.Product.GetType();

            a.Should().Throw<InvalidTypeException>();
        }

        private void ValidateConfidentialInvoiceDiscountFail(SellerApplication application, TestApplicationResult mockResult, int result)
        {
            var expectedCompanyDataRequest = BuildExpected(application.CompanyData as SellerCompanyData);
            result.Should().Be(-1);
            _service.Received(1)
                    .SubmitApplicationFor(
                        Arg.Is<CompanyDataRequest>(actual => IsExpected(expectedCompanyDataRequest, actual)),
                        (application.Product as ConfidentialInvoiceDiscount).TotalLedgerNetworth,
                        (application.Product as ConfidentialInvoiceDiscount).AdvancePercentage,
                        (application.Product as ConfidentialInvoiceDiscount).VatRate);
        }

        private void ValidateConfidentialInvoiceDiscountSuccess(SellerApplication application, TestApplicationResult mockResult, int result)
        {
            var expectedCompanyDataRequest = BuildExpected(application.CompanyData as SellerCompanyData);
            result.Should().Be(mockResult.ApplicationId);
            _service.Received(1)
                    .SubmitApplicationFor(
                    Arg.Is<CompanyDataRequest>(actual => IsExpected(expectedCompanyDataRequest, actual)),
                    (application.Product as ConfidentialInvoiceDiscount).TotalLedgerNetworth,
                    (application.Product as ConfidentialInvoiceDiscount).AdvancePercentage,
                    (application.Product as ConfidentialInvoiceDiscount).VatRate);

        }

        private static SellerApplication BuildConfidentialInvoiceDiscountApplication()
        {
            var confidentialInvoiceDiscount = BuildConfidentialInvoiceDiscount();
            var companyData = BuildCompanyData();
            var application = new SellerApplication(confidentialInvoiceDiscount, companyData);
            return application;
        }

        private TestApplicationResult SetupConfidentialInvoiceServiceSuccess()
        {
            var applicationId = 123;
            var mockResult = new TestApplicationResult(applicationId, true, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<CompanyDataRequest>(), Arg.Any<decimal>(), Arg.Any<decimal>(), Arg.Any<decimal>())
                                       .Returns(mockResult);
            return mockResult;
        }

        private TestApplicationResult SetupConfidentialInvoiceServiceFail()
        {
            var applicationId = 123;
            var mockResult = new TestApplicationResult(applicationId, false, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<CompanyDataRequest>(), Arg.Any<decimal>(), Arg.Any<decimal>(), Arg.Any<decimal>())
                    .Returns(mockResult);
            return mockResult;
        }
    }
}
