﻿using FluentAssertions;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using static SlothEnterprise.ProductApplication.Tests.TestUtilities;


namespace SlothEnterprise.ProductApplication.Tests
{
    public class SubmitApplicationFactoryTests
    {
        private readonly ISubmitApplicationServiceFactory _sut;

        public SubmitApplicationFactoryTests()
        {
            var container = ProductApplicationContainer.Get();

            _sut = new SubmitApplicationServiceFactory(container);
        }

        [Fact]
        public void When_Business_Loan()
        {
            var product = BuildBusinessLoan();

            var result = _sut.SelectFor(product);

            result.Should().BeOfType<BusinessLoanApplicationService>();
        }

        [Fact]
        public void When_Selective_Invoice_Discount()
        {
            var product = BuildSelectiveInvoiceDiscount();

            var result = _sut.SelectFor(product);

            result.Should().BeOfType<SelectiveInvoiceApplicationService>();
        }

        [Fact]
        public void When_Confidential_Invoice_Discount()
        {
            var product = BuildConfidentialInvoiceDiscount();

            var result = _sut.SelectFor(product);

            result.Should().BeOfType<ConfidentialInvoiceApplicationService>();
        }

        [Fact]
        public void When_Product_Invalid()
        {
            var product = new InvalidProduct();

            Action a = () => _sut.SelectFor(product);

            a.Should().Throw<ProductNotRegisteredException>();
        }
    }
}
