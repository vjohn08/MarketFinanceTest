﻿using FluentAssertions;
using NSubstitute;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;
using Xunit;
using static SlothEnterprise.ProductApplication.Tests.TestUtilities;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class BusinessLoanApplicationServiceTests
    {
        private readonly ISubmitApplicationService _sut;
        private readonly IBusinessLoansService _service;

        public BusinessLoanApplicationServiceTests()
        {
            _service = Substitute.For<IBusinessLoansService>();

            _sut = new BusinessLoanApplicationService(_service);
        }

        [Fact]
        public void When_Product_Business_Loan_Submit_Succeeds()
        {
            var application = BuildBusinessLoanApplication();

            var mockedResult = SetupBusinessLoanApplicationSuccess();

            var result = _sut.Submit(application);

            ValidateBusinessLoanSuccess(application, mockedResult, result);
        }

        [Fact]
        public void When_BusinessLoan_And_Submit_Fails()
        {
            var application = BuildBusinessLoanApplication();

            var mockedResult = SetupBusinessLoanApplicationFail();

            var result = _sut.Submit(application);

            ValidateBusinessLoanFail(application, mockedResult, result);
        }

        [Fact]
        public void When_Not_BusinessLoan()
        {
            var application = BuildInvalidApplication();        

            Action a = () => _sut.Submit(application);

            var invalidType = application.Product.GetType();

            a.Should().Throw<InvalidTypeException>();
        }        

        private void ValidateBusinessLoanFail(SellerApplication application, TestApplicationResult mockResult, int result)
        {
            var expectedCompanyDataRequest = TestUtilities.BuildExpected(application.CompanyData as SellerCompanyData);
            var expectedLoansRequest = BuildExpected(application.Product as BusinessLoans);
            result.Should().Be(-1);
            _service.Received(1)
                    .SubmitApplicationFor(
                    Arg.Is<CompanyDataRequest>(actual => IsExpected(expectedCompanyDataRequest, actual)),
                    Arg.Is<LoansRequest>(actual => IsExpected(expectedLoansRequest, actual)));
        }

        private TestApplicationResult SetupBusinessLoanApplicationFail()
        {
            var applicationId = 123;
            var mockResult = new TestApplicationResult(applicationId, false, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<CompanyDataRequest>(), Arg.Any<LoansRequest>())
                    .Returns(mockResult);
            return mockResult;
        }


        private void ValidateBusinessLoanSuccess(SellerApplication application, TestApplicationResult mockResult, int result)
        {
            var expectedCompanyDataRequest = TestUtilities.BuildExpected(application.CompanyData as SellerCompanyData);
            var expectedLoansRequest = BuildExpected(application.Product as BusinessLoans);
            result.Should().Be(mockResult.ApplicationId);
            _service.Received(1)
                    .SubmitApplicationFor(
                    Arg.Is<CompanyDataRequest>(actual => IsExpected(expectedCompanyDataRequest, actual)),
                    Arg.Is<LoansRequest>(actual => IsExpected(expectedLoansRequest, actual)));           
        }

        public static LoansRequest BuildExpected(BusinessLoans businessLoan)
        {
            return new LoansRequest
            {
                InterestRatePerAnnum = businessLoan.InterestRatePerAnnum,
                LoanAmount = businessLoan.LoanAmount
            };
        }

        private TestApplicationResult SetupBusinessLoanApplicationSuccess()
        {
            var applicationId = 123;
            var mockResult = new TestApplicationResult(applicationId, true, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<CompanyDataRequest>(), Arg.Any<LoansRequest>())
                    .Returns(mockResult);
            return mockResult;
        }
    }
}
