﻿using FluentAssertions;
using SlothEnterprise.External;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ExtensionMethods;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class ProductApplicationExtensionTests
    {
        [Fact]
        public void When_Company_Data_Null()
        {
            var application = new SellerApplication(null, null);

            Action a = () => application.ToCompanyDataRequest();

            a.Should().Throw<NullReferenceException>();
        }

        [Fact]
        public void When_Company_Data_Present()
        {
            var companyData = BuildCompanyData();

            var application = new SellerApplication(null, companyData);

            var result = application.ToCompanyDataRequest();

            result.CompanyFounded.Should().Be(companyData.Founded);
            result.CompanyName.Should().Be(companyData.Name);
            result.CompanyNumber.Should().Be(companyData.Number);
            result.DirectorName.Should().Be(companyData.DirectorName);
        }

        [Fact]
        public void When_Loan_Data_Present()
        {
            var loan = new BusinessLoans(1, 19, 30);

            var result = loan.ToRequest();

            result.InterestRatePerAnnum.Should().Be(loan.InterestRatePerAnnum);
            result.LoanAmount.Should().Be(loan.LoanAmount);
        }

        [Fact]
        public void When_Result_Success()
        {
            var applicationResult = new TestApplicationResult(12, success: true, errors: new List<string>());

            var result = applicationResult.GetApplicationId();

            result.Should().Be(applicationResult.ApplicationId);
        }

        [Fact]
        public void When_Result_Fail()
        {
            var applicationResult = new TestApplicationResult(12, success: false, errors: new List<string>());

            var result = applicationResult.GetApplicationId();

            result.Should().Be(-1);
        }

        [Fact]
        public void When_ApplicationId_Null()
        {
            var applicationResult = new TestApplicationResult(null, success: false, errors: new List<string>());

            var result = applicationResult.GetApplicationId();

            result.Should().Be(-1);
        }

        private static SellerCompanyData BuildCompanyData()
        {
            return new SellerCompanyData("Test Name", 123, "Test Director", new DateTime(2010, 10, 10));
        }

        private class TestApplicationResult : IApplicationResult
        {
            public int? ApplicationId { get; set; }
            public bool Success { get; set; }
            public IList<string> Errors { get; set; }

            public TestApplicationResult(int? applicationId, bool success, IList<string> errors)
            {
                ApplicationId = applicationId;
                Success = success;
                Errors = errors;
            }
        }
    }
}
