﻿using FluentAssertions;
using Moq;
using NSubstitute;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;
using System.Collections.Generic;
using Xunit;
using static SlothEnterprise.ProductApplication.Tests.TestUtilities;


namespace SlothEnterprise.ProductApplication.Tests
{
    public class ProductApplicationTests
    {
        private readonly IProductApplicationService _sut;
        private readonly ISubmitApplicationServiceFactory _factory;
        private readonly ISubmitApplicationService _submitService;

        public ProductApplicationTests()
        {
            _factory = Substitute.For<ISubmitApplicationServiceFactory>();
            _submitService = Substitute.For<ISubmitApplicationService>();
                        
            _sut = new ProductApplicationService(_factory);
        }

        [Fact]
        public void Can_Submit_Application()
        {
            var application = BuildBusinessLoanApplication();

            int applicationId = SetupMock(application);

            var result = _sut.SubmitApplicationFor(application);

            result.Should().Be(applicationId);
            _submitService.Received(1).Submit(application);
        }

        private int SetupMock(SellerApplication application)
        {
            _factory.SelectFor(application.Product).Returns(_submitService);

            var applicationId = 123;
            _submitService.Submit(Arg.Any<ISellerApplication>()).Returns(applicationId);
            return applicationId;
        }
    }
}