﻿using FluentAssertions;
using NSubstitute;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;
using System;
using System.Collections.Generic;
using Xunit;
using static SlothEnterprise.ProductApplication.Tests.TestUtilities;

namespace SlothEnterprise.ProductApplication.Tests
{
    public class SelectiveInvoiceApplicationServiceTests
    {
        private readonly ISubmitApplicationService _sut;
        private readonly ISelectInvoiceService _service;

        public SelectiveInvoiceApplicationServiceTests()
        {
            _service = Substitute.For<ISelectInvoiceService>();

            _sut = new SelectiveInvoiceApplicationService(_service);
        }

        [Fact]
        public void When_SelectInvoiceService_And_Submit_Succeeds()
        {
            var companyNumber = "123";
            var application = BuildSelectiveInvoiceServiceApplication(companyNumber);

            var mockedResult = SetupSelectiveInvoiceDiscountSuccess();

            var result = _sut.Submit(application);

            ValidateSelectiveInvoiceDiscountSuccess(application, mockedResult, result, companyNumber);
        }

        [Fact]
        public void When_SelectInvoiceService_And_Submit_Fails()
        {
            var companyNumber = "123";
            var application = BuildSelectiveInvoiceServiceApplication(companyNumber);

            var mockedResult = SetupSelectiveInvoiceDiscountFail();

            var result = _sut.Submit(application);

            ValidateSelectiveInvoiceDiscountFail(application, mockedResult, result, companyNumber);
        }

        [Fact]
        public void When_Invalid_Product()
        {
            var application = BuildInvalidApplication();

            Action a = () => _sut.Submit(application);

            var invalidType = application.Product.GetType();

            a.Should().Throw<InvalidTypeException>();
        }

        private void ValidateSelectiveInvoiceDiscountFail(SellerApplication application, TestApplicationResult mockResult, int result, string companyNumber)
        {
            var expectedCompanyDataRequest = BuildExpected(application.CompanyData as SellerCompanyData);
            result.Should().Be(-1);

            _service.Received(1)
                                 .SubmitApplicationFor(
                                    companyNumber,
                                    (application.Product as SelectiveInvoiceDiscount).InvoiceAmount,
                                    (application.Product as SelectiveInvoiceDiscount).AdvancePercentage
                                    );           

        }

        private TestApplicationResult SetupSelectiveInvoiceDiscountFail()
        {
            var applicationId = -1;
            var mockResult = new TestApplicationResult(-1, false, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<string>(), Arg.Any<decimal>(), Arg.Any<decimal>())
                    .Returns(applicationId);
            return mockResult;
        }

        private void ValidateSelectiveInvoiceDiscountSuccess(SellerApplication application, TestApplicationResult mockResult, int result, string companyNumber)
        {
            var expectedCompanyDataRequest = BuildExpected(application.CompanyData as SellerCompanyData);
            result.Should().Be(mockResult.ApplicationId);
            _service.Received(1)
                    .SubmitApplicationFor(
                        companyNumber,
                        (application.Product as SelectiveInvoiceDiscount).InvoiceAmount,
                        (application.Product as SelectiveInvoiceDiscount).AdvancePercentage
                        );

        }

        private static CompanyDataRequest BuildExpected(SellerCompanyData companyData)
        {
            return new CompanyDataRequest
            {
                CompanyFounded = companyData.Founded,
                CompanyName = companyData.Name,
                CompanyNumber = companyData.Number,
                DirectorName = companyData.DirectorName
            };
        }

        private static SellerApplication BuildSelectiveInvoiceServiceApplication(string companyNumber)
        {
            var selectiveInvoiceDiscount = BuildSelectiveInvoiceDiscount();
            var companyData = BuildCompanyData();
            var application = new SellerApplication(selectiveInvoiceDiscount, companyData);
            return application;
        }

        private TestApplicationResult SetupSelectiveInvoiceDiscountSuccess()
        {
            var applicationId = 123;
            var mockResult = new TestApplicationResult(applicationId, true, new List<string>());
            _service.SubmitApplicationFor(Arg.Any<string>(), Arg.Any<decimal>(), Arg.Any<decimal>())
                    .Returns(applicationId);
            return mockResult;
        }
    }
}
