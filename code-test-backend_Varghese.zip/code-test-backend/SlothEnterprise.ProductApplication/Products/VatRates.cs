﻿namespace SlothEnterprise.ProductApplication.Products
{
    public class VatRates
    {
        public const decimal UkVatRate = 0.20M;
    }

    public class SelectiveInvoiceDiscountRates
    {
        public const decimal DefaultAdvancePercentage = 0.80M;
    }
}