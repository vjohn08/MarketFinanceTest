﻿namespace SlothEnterprise.ProductApplication.Products
{
    public class ConfidentialInvoiceDiscount : IProduct
    {
        public int Id { get; }
        public decimal TotalLedgerNetworth { get; }
        public decimal AdvancePercentage { get; }
        public decimal VatRate { get;} 

        public ConfidentialInvoiceDiscount(int id, decimal totalLedgerNetworth, decimal advancePercentage, decimal vatRate = VatRates.UkVatRate)
        {
            Id = id;
            TotalLedgerNetworth = totalLedgerNetworth;
            AdvancePercentage = advancePercentage;
            VatRate = vatRate;
        }
    }
}