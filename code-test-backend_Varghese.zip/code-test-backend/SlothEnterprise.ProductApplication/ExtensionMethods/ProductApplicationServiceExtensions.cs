﻿using SlothEnterprise.External;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication.ExtensionMethods
{
    public static class ProductApplicationServiceExtensions
    {
        public static CompanyDataRequest ToCompanyDataRequest(this ISellerApplication application)
            => new CompanyDataRequest
            {
                CompanyFounded = application.CompanyData.Founded,
                CompanyName = application.CompanyData.Name,
                CompanyNumber = application.CompanyData.Number,
                DirectorName = application.CompanyData.DirectorName
            };

        public static LoansRequest ToRequest(this BusinessLoans loan)
            => new LoansRequest
            {
                InterestRatePerAnnum = loan.InterestRatePerAnnum,
                LoanAmount = loan.LoanAmount
            };

        public static int GetApplicationId(this IApplicationResult result)
            => (result.Success)
                ? result.ApplicationId ?? -1
                : -1;
    }
}
