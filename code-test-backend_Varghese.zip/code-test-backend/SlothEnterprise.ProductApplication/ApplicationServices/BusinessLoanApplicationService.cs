﻿using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ExtensionMethods;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public class BusinessLoanApplicationService : ISubmitApplicationService
    {
        private readonly IBusinessLoansService _service;

        public BusinessLoanApplicationService(IBusinessLoansService service)
        {
            _service = service;
        }
        public int Submit(ISellerApplication application)
        {
            Validate(application);

            var loans = application.Product as BusinessLoans;

            var result = _service.SubmitApplicationFor(application.ToCompanyDataRequest(), loans.ToRequest());

            return result.GetApplicationId();
        }

        private static void Validate(ISellerApplication application)
        {
            if (application.Product.GetType() != typeof(BusinessLoans))
                throw new InvalidTypeException(typeof(BusinessLoans), application.Product.GetType());
        }
    }
}
