﻿using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ExtensionMethods;
using SlothEnterprise.ProductApplication.Products;
using System;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public class ConfidentialInvoiceApplicationService : ISubmitApplicationService
    {
        private readonly IConfidentialInvoiceService _service;

        public ConfidentialInvoiceApplicationService(IConfidentialInvoiceService service)
        {
            _service = service;
        }

        public int Submit(ISellerApplication application)
        {             
            Validate(application);

            var cid = application.Product as ConfidentialInvoiceDiscount;

            var result = _service.SubmitApplicationFor(
                                application.ToCompanyDataRequest(),
                                cid.TotalLedgerNetworth,
                                cid.AdvancePercentage,
                                cid.VatRate);

            return result.GetApplicationId();
        }

        private static void Validate(ISellerApplication application)
        {
            if (application.Product.GetType() != typeof(ConfidentialInvoiceDiscount))
                throw new InvalidTypeException(typeof(ConfidentialInvoiceDiscount), application.Product.GetType());
        }
    }
}
