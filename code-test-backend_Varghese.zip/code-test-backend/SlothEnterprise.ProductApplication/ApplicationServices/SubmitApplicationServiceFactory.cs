﻿using Autofac;
using Autofac.Core.Registration;
using SlothEnterprise.ProductApplication.Products;
using System;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public class SubmitApplicationServiceFactory : ISubmitApplicationServiceFactory
    {
        private readonly IContainer _container;

        public SubmitApplicationServiceFactory(IContainer container)
        {
            _container = container;
        }

        public ISubmitApplicationService SelectFor(IProduct product)
        {
            try
            {
                return _container.ResolveKeyed<ISubmitApplicationService>(product.GetType());
            }
            catch (ComponentNotRegisteredException)
            {
                throw new ProductNotRegisteredException(product.GetType());
            }
        }
    }
}
