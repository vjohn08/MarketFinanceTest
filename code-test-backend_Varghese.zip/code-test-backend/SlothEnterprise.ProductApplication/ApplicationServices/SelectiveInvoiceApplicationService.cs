﻿using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public class SelectiveInvoiceApplicationService : ISubmitApplicationService
    {
        private readonly ISelectInvoiceService _service;

        public SelectiveInvoiceApplicationService(ISelectInvoiceService service)
        {
            _service = service;
        }
        public int Submit(ISellerApplication application)
        {
            Validate(application);

            var sid = application.Product as SelectiveInvoiceDiscount;

            var result = _service.SubmitApplicationFor(application.CompanyData.Number.ToString(), 
                                                       sid.InvoiceAmount, 
                                                       sid.AdvancePercentage);

            return result;
        }

        private static void Validate(ISellerApplication application)
        {
            if (application.Product.GetType() != typeof(SelectiveInvoiceDiscount))
                throw new InvalidTypeException(typeof(SelectiveInvoiceDiscount), application.Product.GetType());
        }
    }
}
