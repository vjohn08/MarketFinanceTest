﻿using SlothEnterprise.ProductApplication.Applications;
using System.Collections.Generic;
using System.Text;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public interface ISubmitApplicationService
    {
        int Submit(ISellerApplication application);
    }
}
