﻿using SlothEnterprise.ProductApplication.Products;
using System.Collections.Generic;
using System.Text;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public interface ISubmitApplicationServiceFactory
    {
        ISubmitApplicationService SelectFor(IProduct product);
    }
}
