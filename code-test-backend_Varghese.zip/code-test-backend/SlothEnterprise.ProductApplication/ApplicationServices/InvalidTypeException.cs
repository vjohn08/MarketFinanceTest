﻿using System;

namespace SlothEnterprise.ProductApplication.ApplicationServices
{
    public class InvalidTypeException : InvalidOperationException
    {
        public InvalidTypeException(Type expected, Type actual) : base(CreateMessage(expected, actual))
        {

        }

        private static string CreateMessage(Type expected, Type actual)
        {
            return "Expected to have type: " + expected.ToString() + "but has type: " + actual.ToString();
        }
    }

    public class ProductNotRegisteredException : InvalidOperationException
    {
        public ProductNotRegisteredException(Type type) : base(CreateMessage(type))
        {

        }

        private static string CreateMessage(Type type)
        {
            return "The product is not registered: " + type.ToString();
        }
    }
}
