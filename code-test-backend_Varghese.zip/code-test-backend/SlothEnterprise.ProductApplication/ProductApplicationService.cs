﻿using System;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.Applications;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;

namespace SlothEnterprise.ProductApplication
{
    public class ProductApplicationService : IProductApplicationService
    {
        private readonly ISubmitApplicationServiceFactory _factory;

        public ProductApplicationService(ISubmitApplicationServiceFactory factory)
        {
            _factory = factory;
        }

        public int SubmitApplicationFor(ISellerApplication application)
        {
            return _factory.SelectFor(application.Product)
                           .Submit(application);                                                 
        }
    }
}
