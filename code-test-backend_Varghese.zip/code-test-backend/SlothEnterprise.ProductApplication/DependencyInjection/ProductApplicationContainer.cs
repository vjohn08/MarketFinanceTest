﻿using Autofac;
using SlothEnterprise.External;
using SlothEnterprise.External.V1;
using SlothEnterprise.ProductApplication.ApplicationServices;
using SlothEnterprise.ProductApplication.Products;
using IContainer = Autofac.IContainer;

namespace SlothEnterprise.ProductApplication.DependencyInjection
{
    public static class ProductApplicationContainer
    {
        public static IContainer Get()
        {
            var builder = new ContainerBuilder();

            builder.RegisterType<BusinessLoanApplicationService>().Keyed(typeof(BusinessLoans), typeof(ISubmitApplicationService));
            builder.RegisterType<SelectiveInvoiceApplicationService>().Keyed(typeof(SelectiveInvoiceDiscount), typeof(ISubmitApplicationService));
            builder.RegisterType<ConfidentialInvoiceApplicationService>().Keyed(typeof(ConfidentialInvoiceDiscount), typeof(ISubmitApplicationService));

            builder.RegisterType<FakeBusinessLoanService>().As<IBusinessLoansService>();
            builder.RegisterType<FakeSelectInvoiceService>().As<ISelectInvoiceService>();
            builder.RegisterType<FakeConfidentialInvoiceService>().As<IConfidentialInvoiceService>();

            return builder.Build();
        }
    }

    //These class are external dependences implementing the external service and should be added.
    public class FakeBusinessLoanService : IBusinessLoansService
    {
        public IApplicationResult SubmitApplicationFor(CompanyDataRequest applicantData, LoansRequest businessLoans)
        {
            throw new System.NotImplementedException();
        }
    }

    public class FakeSelectInvoiceService : ISelectInvoiceService
    {
        public int SubmitApplicationFor(string companyNumber, decimal invoiceAmount, decimal advancePercentage)
        {
            throw new System.NotImplementedException();
        }
    }

    public class FakeConfidentialInvoiceService : IConfidentialInvoiceService
    {
        public IApplicationResult SubmitApplicationFor(CompanyDataRequest applicantData, decimal invoiceLedgerTotalValue, decimal advantagePercentage, decimal vatRate)
        {
            throw new System.NotImplementedException();
        }
    }
}
